// scripts.js
document.addEventListener("DOMContentLoaded", function() {
    const movieCards = document.querySelector('.movie-cards');

    // Devara Movie Card
    const devaraCard = document.createElement('div');
    devaraCard.classList.add('movie-card');
    devaraCard.innerHTML = `<img src="https://example.com/devara-image.jpg" alt="Devara"><h3>Devara</h3>`;
    movieCards.appendChild(devaraCard);

    // Baahubali Movie Card
    const baahubaliCard = document.createElement('div');
    baahubaliCard.classList.add('movie-card');
    baahubaliCard.innerHTML = `<img src="https://example.com/baahubali-image.jpg" alt="Baahubali"><h3>Baahubali</h3>`;
    movieCards.appendChild(baahubaliCard);
});
document.addEventListener("DOMContentLoaded", function() {
    const movieCards = document.querySelector('.movie-cards');

    // Devara Movie Card
    const devaraCard = document.createElement('div');
    devaraCard.classList.add('movie-card');
    devaraCard.innerHTML = `
        <img src="images/devars.jpg" alt="Devara">
        <h3>Devara</h3>
    `;
    movieCards.appendChild(devaraCard);
});
